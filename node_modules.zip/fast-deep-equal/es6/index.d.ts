declare const equal: (a: any, b: any) => boolean;
export = equal;
